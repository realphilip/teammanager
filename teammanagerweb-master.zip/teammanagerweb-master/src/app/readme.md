The frontend to github.com/realphilip/teammanager

Made with Angular, JS/TS

CSS: Bootstrap
